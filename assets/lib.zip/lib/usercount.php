<?php
	function nombre_visiteurs() {
		try {
			$base = [];
			$filename = $_SERVER['DOCUMENT_ROOT']."database/count.txt";
			if(is_file($filename)) {
				if (($handle = fopen($filename, "r")) !== FALSE) {	
					$count = intval(fread($handle, filesize($filename)));
					fclose($handle);
					return $count;
				}
			}
		}
		catch(Exception $e) {
			return 0;
		}
		return 0;
	}
	
	function incrementer_nombre_visiteurs() {
		$count = nombre_visiteurs() + 1;
		$filename = $_SERVER['DOCUMENT_ROOT']."database/count.txt";
		$dirname = dirname($filename);
		if (!is_dir($dirname))
		{
			mkdir($dirname, 0755, true);
		}
		$file = fopen($filename, 'w');
		fwrite($file, $count);
		fclose($file);
	}
?>