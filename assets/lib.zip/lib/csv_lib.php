<?php
	function ouvrir_base() {
		$base = [];
		$filename = $_SERVER['DOCUMENT_ROOT']."database/users.csv";
		$dirname = dirname($filename);
		if (!is_dir($dirname))
		{
			mkdir($dirname, 0755, true);
		}
		if(!is_file($filename)) {
			$file = fopen($filename, "w");
			fclose($file);
		}
		if (($handle = fopen($filename, "r")) !== FALSE) {
			$index = 0;
			while (($data = fgetcsv($handle, 2000, ",")) !== FALSE) {
				if($index == 0) {
					$keys = $data;
					$keysSize = count($keys);
				}
				else {
					$num = count($data);
					if(!empty($data)) {
						$user = [];
						for ($c=0; $c < $num; $c++) {
							$user[$keys[$c]] = $data[$c];
						}
						array_push($base, $user);
					}
				}
				$index = $index + 1;
			}
			fclose($handle);
		}
		return $base;
	}
	
	function sauvegarder_base($base) {
		$filename = $_SERVER['DOCUMENT_ROOT']."database/users.csv";
		$dirname = dirname($filename);
		if (!is_dir($dirname))
		{
			mkdir($dirname, 0755, true);
		}
		$file = fopen($filename, 'w');
		if(!empty($base)) {
			$keys = array_keys($base[0]);
			fputcsv($file, $keys);
			foreach ($base as $user) {
				fputcsv($file, $user);
			}
		}
		fclose($file);
	}
	
	function chercher_base($base, $condition) {
		$results = [];
		foreach ($base as $user) {
			if(eval('return ('.$condition.');')) {
				array_push($results, $user);
			}
		}
		return $results;
	}
?>