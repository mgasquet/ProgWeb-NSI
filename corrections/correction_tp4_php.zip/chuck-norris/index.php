<?php
	require './lib/usercount.php';
	incrementer_nombre_visiteurs();
?>

<!--positionner les balises doctype, html ici -->
<!DOCTYPE html>
<html>
  <!-- Ouvrir la balise head ici -->
	<head>
		<!-- Mettre un titre au document ici -->
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/styles.css">
		<title>Le site non officiel de Chuck Norris</title>
		<!-- Fermer la balise head ici -->
	</head>


<!-- ouvrir la balise body ici -->
	<body id="debut">
		<header>
			<nav>
				<a href="index.php">Accueil</a>
				<a href="inscription.php">Inscription</a>
				<a href="listeMembres.php">Liste des membres</a>
			</nav>
		</header>
		<main>
			<!-- utiliser blockquote ici  -->
			
			<blockquote><p>"Little John: Braddock ! Je vous préviens, attention où vous mettez les pieds !<br>
				 Braddock : Je mets les pieds où je veux, Little John… et c'est souvent dans la gueule."</p>
				<cite>Chuck Norris, Portés disparus 3 (1988), écrit par Arthur Silver, Larry Levinson, James Bruner, Chuck Norris, Steve Bing</cite>
			</blockquote>
			
			<?php 
				date_default_timezone_set('Europe/Paris');
				setlocale(LC_TIME, "fr_FR");
				$today = ucfirst(strftime("%A %d %b %Y", strtotime(date('Y-m-d'))));
			?>
			<p><strong>Bienvenue sur le site de Chuck Norris ! - <?php echo $today;?></strong></p>
			<?php 
				$numero_visiteur = nombre_visiteurs();
			?>
			<p><strong>Nombre de visiteurs : <?php echo $numero_visiteur; ?><strong></p>

			<!--section -->
			<h2 class="pair">Biographie (From Wikipedia)</h2>


		<!--sous section -->
			<h3 class="pair">L'enfance</h3>

			<!--l'image de Chuck Young doit être positionnée ici  -->
			<img src="./images/chuck-jeune.jpg" alt="chuck jeune">

			<!--début paragraphe -->
			<p>Carlos Ray Norris, plus connu en tant que Chuck Norris, est un acteur américain né le 10 mars 1940 à Ryan (Oklahoma). Spécialiste en arts martiaux, il s'est essentiellement consacré au cinéma d'action. Natif de Ryan dans l'Oklahoma, Carlos Ray Norris
				a deux frères cadets dont l'un est le producteur hollywoodien Aaron Norris. Ses parents sont de souche amérindienne (cherokee) et irlandaise. Ses parents divorcent alors qu'il a 16 ans et il déménage en Californie avec sa mère et ses frères. C'est là
				qu'il finit ses études au lycée et se marie rapidement avec sa petite amie, Diane Holechek.</p>
				<!--fin paragraphe -->

			<!--sous section -->
			<h3 class="impair">L'armée</h3>

		<!--début paragraphe -->
				<p>Après son mariage, il rejoint l'US Air Force et est envoyé faire son service militaire à la base d'Osan, en Corée du Sud. C'est là qu'il acquiert le surnom de Chuck et qu'il commence à apprendre le <span class="skill">Tangsudo</span>. Il retourne ensuite aux États-Unis,
				dans la base de March, en Californie. Il termine ses services à l'armée en août 1962 sans avoir pris part à un autre combat que les entraînements de la base. </p>
		<!--fin paragraphe -->
			

		<!--sous section -->
			<h3 class="pair">Les sports de combats</h3>


			<!--début paragraphe -->
				<p>À son retour, il travaille pour la société Northrop Grumman et ouvre une école de <span class="skill">Karaté</span> fréquentée par de nombreuses célébrités, dont Steve McQueen. Son fils Mike naît en 1963 suivi par sa fille Dina en 1964 et d'un second fils, Eric, en 1965.
			
			Le palmarès de Chuck est impressionnant :</p>
						<!--liste  -->
						<ul>
						<li>Il possède une ceinture noire en <span class="skill">Tangsudo</span> et en <span class="skill">Taekwondo</span>,</li>
				
						<li>Il est le fondateur du <span class="skill">Chun Kuk Do</span> (La voie universelle).</li>
				
						<li>Il a également pratiqué le <span class="skill">Karaté</span> (7 fois champion du monde des poids moyens de 1968 à 1974)</li>
				
						<li>Il a aussi fait du <span class="skill">Judo</span> et du <span class="skill">Ju-jitsu</span></li>
						</ul>
				
			<!--sous section -->
			<h3 class="impair">Le cinéma</h3>
				<!--début paragraphe -->
					<p>L'année 1964 marque un tournant dans la vie de Chuck Norris quand il rencontre Bruce
					<!--l'image de Chuck Beware ici   -->
					<img id="beware" src="./images/beware.jpg" alt="chuck beware">
					
					Lee. Malgré une amitié affichée entre les deux hommes, il semble cependant que leurs relations ont été parfois tumultueuses. En 1968, Norris devient champion de <span class="skill">Karaté</span> dans la catégorie poids moyen, et en 1969, il remporte la triple couronne en <span class="skill">Karaté</span>
					pour le record des tournois remportés dans l'année, et le titre de combattant de l'année par le Black Belt Magazine. C'est en 1968 qu'il débute au cinéma, dans The Wrecking Crew. En 1970, son plus jeune frère Weiland meurt au Viêt Nam : Chuck lui dédiera
					plus tard son film Portés disparus. En 1972, il joue avec Bruce Lee dans 
					<!-- lien externe vers  "http://www.imdb.com/title/tt0068935/" libellé par "La Fureur du dragon".  -->
					<a href="http://www.imdb.com/title/tt0068935/">La Fureur du dragon</a>
					, et en 1974, McQueen l'encourage à prendre des cours d'art dramatique au MGM Studio, sous la férule de
					Jonathan Harris. Il enchaîne alors les succès avec des séries de films : Invasion U.S.A., Portés disparus ou encore Delta Force. Après trente ans de mariage, Norris et Holechek divorcent. En 1990, Norris crée l'association Kick Drugs Out of America,
					renommée depuis Kick Start. Mais à la fin des années 1980, Norris ne remplit plus autant les salles, et son producteur principal Cannon Group, à l'origine de ses films, est racheté par la MGM après sa banqueroute. Il se tourne alors vers la télévision
					en se lançant en 1993 dans la série Walker, Texas Ranger. Cette série est un succès : elle compte neuf saisons et continue d'être diffusée sur de très nombreuses chaînes à travers le monde.
					</p>
					<!--fin paragraphe -->

		<!--sous section -->
				<h3 class="pair">Ces vingt dernières années</h3>
				<!--début paragraphe -->
				<p>En 1994, aux Survivor Series (pay-per-view de la WWE), il arbitre un Special Guest Referee Casket Match entre The Undertaker et Yokozuna. En 1997, il obtient un 8e dan (degré) en <span class="skill">Taekwondo</span>, qui en comporte 10. 
				<!-- mettre en emphase cette phrase -->
				<em>Cette distinction le hisse au rang de Grand
					Maître. Il est un des premiers occidentaux à qui elle a été attribuée. </em>


					Il se remarie, en 1998, avec l'ancien mannequin Gena O'Kelley qui lui a donné des jumeaux en 2002 : Dakota Alan Norris, un garçon, et Danilee Kelly Norris, une fille.</p>
				<!--fin paragraphe -->


		<!--section -->
				<h2 class="impair">Les sites amis</h2> 
				<!--liste  -->
					<ul>
						<!-- lien externe  libellé par "chucknorrisfacts".  -->
						<li><a href="http://www.chucknorrisfacts.fr">chucknorrisfacts</a></li>
						<!-- lien externe  libellé par "mulletjunky"  -->
						<li><a href="http://www.mulletjunky.com/picfix3.htm">mulletjunky</a></li>
						<!-- lien externe  libellé par "stevenseagal.com"  -->
						<li><a href="http://stevenseagal.com">stevenseagal.com</a></li>
					</ul>

		<!--section -->
				<h2 class="pair">Le Top 10 des derniers facts proposés</h2> 
				
				<!--liste numérotée -->
					<ol>
						<li>Le calendrier de Chuck Norris passe du 31 mars au 2 avril. Personne ne fait de blague à Chuck. </li>
						<li>Quand Chuck Norris fait une prise de sang, il refuse la seringue et demande un fusil à pompe et une bassine.</li> 
						<li>Les extra-terrestres existent : ils attendent juste que Chuck Norris meure avant de passer à l´attaque.</li>
						<li>Chuck Norris peut applaudir d´une seule main. </li>
						<li>Chuck Norris ne dort pas. Il attend. </li>
						<li>La semence de Chuck Norris ne contient qu´un seul spermatozoïde : celui qui a tué tous les autres. </li>
						<li>Les amnésiques se souviennent quand même de Chuck Norris. </li>
						<li>Certaines personnes portent un pyjama Superman. Superman porte un pyjama Chuck Norris.</li>
						<li>Chuck Norris donne fréquemment du sang à la Croix-Rouge. Mais jamais le sien.</li>
						<li>Chuck Norris et Superman ont fait un bras de fer, le perdant devait mettre son slip par dessus son pantalon.</li>
					</ol>


		<!-- lien interne qui permet de revenir par clic au début de la page avec des ancres et avec libellé "Retour au début" -->
			<a href=#debut>Retour au début</a>
		</main>
<!-- fermer la balise body et html ici -->
	</body>
</html>