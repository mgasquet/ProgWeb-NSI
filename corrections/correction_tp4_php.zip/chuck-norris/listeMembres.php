<?php
require "./lib/csv_lib.php";
date_default_timezone_set('Europe/Paris');
setlocale(LC_TIME, "fr_FR");
$base = ouvrir_base();
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="./css/styles.css">
		<title>Membres du fan-club de Chuck Norris</title>
	</head>

	<body>
		<header>
			<nav>
				<a href="index.php">Accueil</a>
				<a href="inscription.php">Inscription</a>
				<a href="listeMembres.php">Liste des membres</a>
			</nav>
		</header>
		<main>
			<?php
				if(empty($base)) {

			?>
					<p><strong>Aucun inscrit!</strong></p>
			<?php
				} //Fermeture du if
				else {
					
			?>
			<p><strong>Liste des membres</strong></p>
			<table border="2px">
			<thead>
				<tr>
					<th>Nom</th>
					<th>Prénom</th>
					<th>Sexe</th>
					<th>Date de naissance</th>
					<th>Email</th>
					<th>Niveau de Karaté</th>
				</tr>
			</thead>
				<tbody>
					<?php
						foreach($base as $user) {
					?>
					<tr>
						<td><?php echo $user["nom"]; ?></td>
						<td><?php echo $user["prenom"]; ?></td>
						<td><?php echo $user["sexe"]; ?></td>
						<td><?php echo $today = ucfirst(strftime("%d %b %Y", strtotime($user["date_naissance"]))); ?></td>
						<td><?php echo $user["email"]; ?></td>
						<td><?php echo $user["niveau_karate"]; ?></td>
					</tr>
					<?php
						} //Fermeture du for
					} //Fermeture du else
					?>
				</tbody>
			</table>
		</main>
	</body>
</html>