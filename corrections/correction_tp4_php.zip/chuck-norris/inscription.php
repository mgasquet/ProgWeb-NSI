<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/styles.css">
		<title>Inscription au fan-club de Chuck Norris</title>
	</head>

	<body>
		<header>
			<nav>
				<a href="index.php">Accueil</a>
				<a href="inscription.php">Inscription</a>
				<a href="listeMembres.php">Liste des membres</a>
			</nav>
		</header>
		<main>
			<form action="validationInscription.php" method="post">
			<fieldset>
				<legend><strong>Informations personnelles</strong></legend>
				<div>
					<label for="surname">Nom<span class="obligatoire">*</span> : </label>
					<input id="surname" name="uname" type="text" required>
				</div>
				<br>
				<div>
					<label for="firstname">Prénom<span class="obligatoire">*</span> : </label>
					<input id="firstname" name="fname" type="text" required>
				</div>
				<br>
				<label><strong>Sexe<span class="obligatoire">*</span> :</strong></label>
				<div>
					<label for="homme">Homme</label>
					<input id="homme" name="sexe" value="h" type="radio" required>
					<label for="femme">Femme</label>
					<input id="femme" name="sexe" value="f" type="radio" required>
				</div>
				<br>
				<div>
					<label for="datenaiss">Date de naissance<span class="obligatoire">*</span> : </label>
					<input id="datenaiss" name="birthdate" type="date" required>
				</div>
				<br>
				<div>
					<label for="pays">Pays d'origine : </label>
					<select id ="pays" name="pays">
						<option value="us">USA</option>
						<option value="fr" selected>France</option>
						<option value="ch">Chine</option>
						<option value="vn">Viêt Nam</option>
					</select>
				</div>			
			</fieldset>
			<br>
			<fieldset>
				<legend><strong>Les sports de combat</strong></legend>
				<div>
					<label for="artsmart">Arts-martiaux préférés : </label>
					<p>
						<select multiple id ="artsmart" name="art">
							<option value="kf">Kung fu</option>
							<option value="kara">Karaté</option>
							<option value="fc">Full-contact</option>
						</select>
					</p>
				</div>
				<div>
					<label for="kara">Niveau de Karaté<span class="obligatoire">*</span> : </label>
					<input id="kara" name="niv_kara" type="number" min="0" max="5" required>
				</div>			
			</fieldset>
			<br>
			<fieldset>
				<legend><strong>Inscription</strong></legend>
				<div>
					<label for="adr_email">Email<span class="obligatoire">*</span> : </label>
					<input id="adr_email" name="adr_email" type="email" placeholder="yourmail@domain.com" required>
				</div>
				<br>
				<div>
					<label for="mdp">Mot de passe<span class="obligatoire">*</span> : </label>
					<input id="mdp" name="pass" type="password" required>
				</div>
				<br>			
				<div>
					<label for="msg_chuck">Message pour Chuck : </label>
					<p>
						<textarea id ="msg_chuck" name="msg" placeholder="Un inscrit sera tiré au sort, et verra son message transmis à Chuck Norris."></textarea>
					</p>
				</div>	
				<label><strong>Niveau d'engagement :</strong></label>
				<div>
					<label for="basique">Basique (5 €)</label>
					<input id="basique" name="engagement" value="basique" type="radio">
					<label for="gold">Gold (15 €)</label>
					<input id="gold" name="engagement" value="gold" type="radio">
					<label for="tatane">Tatane in your face (50 €)</label>
					<input id="tatane" name="engagement" value="tatane" type="radio">
				</div>
				<br>
				<div>
					<label for="conditions"><strong>J’ai bien lu les clauses que je n’ai pas lues<span class="obligatoire">*</span></strong></label>
					<input id="conditions" name="conditions" type="checkbox" required>
				</div>
			</fieldset>
			<br>
			<input type="submit" value="Envoyer">
			</form>
		</main>
	</body>
</html>