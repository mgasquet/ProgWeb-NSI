<?php
require "./lib/csv_lib.php";

$nom = $_POST["uname"];
$prenom = $_POST["fname"];
$sexe = $_POST["sexe"];
$birthdate = $_POST["birthdate"];
$email = $_POST["adr_email"];
$password = $_POST["pass"];
$kara = $_POST["niv_kara"];

$user["nom"] = $nom;
$user["prenom"] = $prenom;
$user["sexe"] = $sexe;
$user["date_naissance"] = $birthdate;
$user["email"] = $email;
$user["mot_de_passe"] = $password;
$user["niveau_karate"] = $kara;

$base = ouvrir_base();
$user_bis = chercher_base($base, '$user["nom"] == "'.$nom.'"');
$inscription_valide = empty($user_bis);

if($inscription_valide) {
	array_push($base, $user);
	sauvegarder_base($base);	
}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="./css/styles.css">
		<title>Inscription au fan-club de Chuck Norris</title>
	</head>

	<body>
		<header>
			<nav>
				<a href="index.php">Accueil</a>
				<a href="inscription.php">Inscription</a>
				<a href="listeMembres.php">Liste des membres</a>
			</nav>
		</header>
		<main>
		<?php
			if($inscription_valide) {
		?>
			<p>Votre inscrption est validée !</p>
			<a href="./index.php">Retour à la page d'accueil</a>
		<?php
			}
			else {
				
		?>
			<p>Votre inscrption a échouée !</p>
			<a href="./inscription.php">Retour à la page d'inscription</a>
		<?php
			}
		?>
		</main>
	</body>
</html>